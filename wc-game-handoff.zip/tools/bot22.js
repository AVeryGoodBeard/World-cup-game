const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
const BEST = process.env.BEST==='1'; const N = +process.argv[2] || 1, VERBOSE = process.argv[3]==='v';
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const results = [];
  for (let t = 0; t < N; t++) {
    const page = await browser.newPage();
    const errs = [];
    page.on('pageerror', e => errs.push(e.message));
    page.on('console', m => { if (m.type()==='error') errs.push('console: '+m.text()); });
    await page.addInitScript((BEST) => {
      const st = window.setTimeout; window.setTimeout = (f, d, ...a) => st(f, Math.min(d||0, 5), ...a);
      window.__BEST = BEST; window.speechSynthesis && (window.speechSynthesis.speak = ()=>{});
    }, BEST);
    await page.goto('file:///home/claude/world-cup-game-v22.html');
    await page.waitForTimeout(200);
    // random nation
    await page.evaluate((nid) => { if(nid){chooseNation(NATIONS.find(n=>n.id===nid));} else selectRandomNation(); }, process.env.NATION||null);
    await page.waitForTimeout(50);
    const log = []; let stuck=0; let loreSeen=[];
    for (let step = 0; step < 400; step++) {
      const state = await page.evaluate(() => {
        const vis = el => el && el.offsetParent !== null && !el.disabled;
        const mo=[...document.querySelectorAll('.manager-option')].filter(vis);
        if(mo.length){ mo[0].click(); return 'manager:'+mo[0].innerText.slice(0,30); }
        // draft phase
        const pick = [...document.querySelectorAll('#player-picker button, .player-option, .pick-btn')].filter(vis);
        if (pick.length) { const P = window.__BEST ? pick.map(b=>[b,Math.max(...(b.innerText.match(/\b\d{2}\b/g)||['0']).map(Number))]).sort((a,b)=>b[1]-a[1])[0][0] : pick[0]; P.click(); return 'pick:'+P.innerText.slice(0,40); return 'pick:'+pick[0].innerText.slice(0,40); }
        const spin = document.getElementById('spin-btn');
        if (vis(spin) && !gameOver) { spin.click(); return 'spin'; }
        const btns = [...document.querySelectorAll('button')].filter(vis)
          .filter(b => !/copy|reset|play again|error|reroll|swap|optimi|anthem|stop|share|decline|skip/i.test(b.innerText+' '+(b.getAttribute('aria-label')||'')));
        const fc = document.getElementById('final-card');
        if (fc && fc.offsetParent !== null && fc.innerText.length > 50) return 'FINAL';
        const pref = btns.find(b => /confirm|start|continue|proceed|draw|kick|play|next|view|advance|begin|enter|lock|done|see|reveal|finish|champion/i.test(b.innerText)) ;
        if (pref) { pref.click(); return 'click:'+pref.innerText.slice(0,40); }
        return 'STUCK:' + btns.map(b=>b.innerText.slice(0,25)).join(' | ');
      });
      log.push(state);
      const ls = await page.evaluate(()=>{ const c=document.getElementById('tournament-card'); const t=c?c.innerText:''; const m=t.match(/(Rivalry match|From the history book|History repeats|History rewritten|Bragging rights|Shootout history|Meanwhile, elsewhere)[^\n]*/); return m?m[0].slice(0,90):null; });
      if(ls && !loreSeen.includes(ls)) loreSeen.push(ls);
      if (state === 'FINAL') break; if (state.startsWith('STUCK')) { stuck=(stuck||0)+1; if (stuck>40) break; await page.waitForTimeout(100); continue; } stuck=0;
      await page.waitForTimeout(state==='spin'?30:15);
    }
    const out = await page.evaluate(() => ({
      nation: selectedNation && selectedNation.id, strength: Math.round(playerStrength),
      journey: journeyLog.map(j=>[j.round,j.score,j.outcome,j.oppName]),
      champ: bracketWinner ? JSON.stringify(bracketWinner).slice(0,150) : null, finalText: (document.getElementById('final-card').innerText||'').slice(0,300),
      bracketLog: bracketLog.length ? bracketLog : null,
      era: eraAttackBonus+'/'+eraDefenseBonus, eraB: (typeof eraEggBracket!=='undefined'?eraEggBracket:null), eraHas: !!(eraEggBracket && ERA_DATA[selectedNation.id] && ERA_DATA[selectedNation.id][eraEggBracket]), lore: tournamentLore.slice(), fp: lastFrontPage, boons: detectBoons(roster,getSlots()).map(b=>b.label), stickers: stickersThisRun.map(x=>x.id), mgr: selectedManager? selectedManager.name+'/'+selectedManager.style : null, ed: hostEdition? hostEdition.year : null, albumFound: Object.keys(albumFound).length,
    }));
    out.errs = errs; out.loreSeen = loreSeen; out.last = log.slice(-3); if (VERBOSE) out.log = log;
    results.push(out);
    await page.close();
  }
  require('fs').writeFileSync(process.argv[4]||'res.json', JSON.stringify(results));
  await browser.close();
})();
