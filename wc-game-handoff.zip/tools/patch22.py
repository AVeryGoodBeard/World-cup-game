import sys
s=open('world-cup-game-v21.html',encoding='utf-8').read()
def rep(old,new,count=1):
    global s
    n=s.count(old)
    if n!=count: sys.exit(f'EXPECTED {count} got {n}: {old[:80]!r}')
    s=s.replace(old,new)
NEW=['drcongo','zambia','southafrica','sudan','ethiopia']
blocks={}; cur=None
for l in open('ga/groupA_pools.txt'):
    l=l.rstrip('\n')
    if l.startswith('NATION|'): cur=l.split('|')[1]; blocks[cur]=[]; continue
    if l: blocks[cur].append(l)
assert all('`' not in x and '$' not in x for b in blocks.values() for x in b)
ins=''.join(f"  {n}: `\n"+'\n'.join(blocks[n])+"\n`,\n" for n in NEW)
i=s.index('const PLAYER_POOL_COMPACT = {'); j=s.index('const FUTURE_PLAYER_POOL_COMPACT'); k=s.rindex('};',i,j)
s=s[:k]+ins+s[k:]
rep("  {id:'congo',      name:'Congo',           flag:'🇨🇬', strength:64},\n];",
    "  {id:'congo',      name:'Congo',           flag:'🇨🇬', strength:64},\n"
    "  {id:'drcongo',    name:'DR Congo',        flag:'🇨🇩', strength:70},\n"
    "  {id:'southafrica',name:'South Africa',    flag:'🇿🇦', strength:70},\n"
    "  {id:'zambia',     name:'Zambia',          flag:'🇿🇲', strength:68},\n"
    "  {id:'ethiopia',   name:'Ethiopia',        flag:'🇪🇹', strength:60},\n"
    "  {id:'sudan',      name:'Sudan',           flag:'🇸🇩', strength:60},\n];")
rep("  mali:'C', burkinafaso:'C', guinea:'C', angola:'C', congo:'C',\n};",
    "  mali:'C', burkinafaso:'C', guinea:'C', angola:'C', congo:'C',\n  drcongo:'C', zambia:'C', southafrica:'C', sudan:'C', ethiopia:'C',\n};")
rep("'angola','congo'],\n};","'angola','congo','drcongo','zambia','southafrica','sudan','ethiopia'],\n};")
rep("const NATION_PALETTES = {\n","const NATION_PALETTES = {\n"
    "  drcongo:     { primary:'#2563eb', secondary:'#facc15', tint:'#121a2a', label:'Leopards colors' },\n"
    "  zambia:      { primary:'#16a34a', secondary:'#ea580c', tint:'#142417', label:'Chipolopolo colors' },\n"
    "  southafrica: { primary:'#facc15', secondary:'#16a34a', tint:'#22200f', label:'Bafana Bafana colors' },\n"
    "  sudan:       { primary:'#dc2626', secondary:'#e5e7eb', tint:'#241414', label:'Falcons of Jediane colors' },\n"
    "  ethiopia:    { primary:'#16a34a', secondary:'#facc15', tint:'#142417', label:'Walia colors' },\n")
mg=[l.strip() for l in open('/mnt/user-data/outputs/managers-final.txt') if l.startswith('MGR|') and l.split('|')[1] in NEW]
first={}
for l in mg: first.setdefault(l.split('|')[1], l.split('|')[2])
rep("const NATION_MANAGERS = {\n","const NATION_MANAGERS = {\n"+''.join(f"  {k}: '{v.replace(chr(39),'')}',\n" for k,v in first.items()))
a=s.index('const MANAGERS_COMPACT = `'); b=s.index('`;',a); s=s[:b]+'\n'+'\n'.join(mg)+s[b:]
rep("if(result.length > 71) console.warn","if(result.length > 76) console.warn")
# Nation history line on the appointment screen
LORE={
 'congo':"Congo won the 1972 Africa Cup of Nations, beating Mali 3-2 in the final.",
 'mali':"Salif Keita was named the first African Footballer of the Year, in 1970.",
 'burkinafaso':"Burkina Faso reached the final of the 2013 Africa Cup of Nations.",
 'guinea':"Cherif Souleymane was African Footballer of the Year in 1972, and Guinea finished second at the 1976 Africa Cup of Nations.",
 'angola':"Angola reached its first World Cup in 2006, and Flavio scored the country's first World Cup goal, against Iran.",
 'drcongo':"As Zaire, DR Congo was the first sub-Saharan African team at a World Cup, in 1974. That year Ndaye Mulamba scored 9 goals at the Africa Cup of Nations, still the record.",
 'zambia':"Kalusha Bwalya was African Footballer of the Year in 1988, and Zambia won the 2012 Africa Cup of Nations.",
 'southafrica':"South Africa won the 1996 Africa Cup of Nations as hosts, and Siphiwe Tshabalala scored the opening goal of the 2010 World Cup.",
 'sudan':"Sudan won the 1970 Africa Cup of Nations at home, beating Ghana 1-0 in the final.",
 'ethiopia':"Ethiopia played in the first Africa Cup of Nations in 1957, and won the title at home in 1962.",
}
lore_js="const NATION_LORE = {\n"+''.join(f"  {k}: \"{v}\",\n" for k,v in LORE.items())+"};\n"
rep("function showManagerPick(n){", lore_js+"function showManagerPick(n){")
rep("""  html += `<p class="album-lead">Three candidates from ${n.name}'s real managers. Your manager shapes how the team plays, and he picks the squad.</p>`;""",
    """  html += `<p class="album-lead">Three candidates from ${n.name}'s real managers. Your manager shapes how the team plays, and he picks the squad.</p>`;
  if(NATION_LORE[n.id]) html += `<p class="album-lead">History: ${NATION_LORE[n.id]}</p>`;""")
rep('aria-label="Build version 21">v21</span>','aria-label="Build version 22">v22</span>')
open('world-cup-game-v22.html','w',encoding='utf-8').write(s)
print('ok, managers',len(mg),first)
