const { chromium } = require('/home/claude/.npm-global/lib/node_modules/playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const p = await b.newPage(); const errs=[];
  p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (/error|warn/.test(m.type()) && !/403/.test(m.text())) errs.push(m.type()+': '+m.text()); });
  await p.goto('file:///home/claude/world-cup-game-v22.html'); await p.waitForTimeout(400);
  const r = await p.evaluate(() => {
    const o={}; o.nations=getAllNations().length;
    o.pools=['drcongo','zambia','southafrica','sudan','ethiopia'].map(n=>{const pl=getSafePool(n); return n+':'+pl.length+':GK'+pl.filter(x=>x.type==='GK').length;});
    o.mgrs=['drcongo','zambia','southafrica','sudan','ethiopia'].map(n=>n+':'+(MANAGERS[n]||[]).length);
    o.btn=!!document.querySelector('[data-nation="mali"], button[aria-label*="Mali"]');
    o.cat=stickerCatalog().length;
    return o;
  });
  r.errs=errs; console.log(JSON.stringify(r)); await b.close();
})();
