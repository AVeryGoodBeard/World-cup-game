const fs=require('fs');const s=fs.readFileSync('g22.js','utf8');
function pool(n){const m=s.match(new RegExp('\\n *'+n+': *`\\n?([\\s\\S]*?)`'));return m[1].trim().split('\n').map(l=>{const p=l.split('|');return p[0]==='GK'?{type:'GK',name:p[1],sto:+p[3],cmd:+p[4],dis:+p[5]}:{type:p[0],pos:p[1],name:p[2],atk:+p[4],def:+p[5],phy:+p[6],inf:+p[7]};});}
function xi(n){const P=pool(n);const best=(t,c)=>P.filter(p=>p.type===t).sort((a,b)=>(b.type==='GK'?b.sto-a.sto:Math.max(b.atk,b.def,b.inf)-Math.max(a.atk,a.def,a.inf))).slice(0,c);return[...best('GK',1),...best('DEF',4),...best('MID',3),...best('FOR',3)];}
const E={damp(a,b,s=0.015){return Math.tanh((a-b)*s)*0.22;},
unit(l,t){const P=l.filter(p=>p.type===t);if(!P.length)return 70;
 if(t==='DEF')return P.reduce((x,p)=>x+(p.def*0.55+p.phy*0.25+p.inf*0.2),0)/P.length;
 if(t==='MID')return P.reduce((x,p)=>x+(p.atk*0.3+p.def*0.3+p.inf*0.25+p.phy*0.15),0)/P.length;
 if(t==='FOR')return P.reduce((x,p)=>x+(p.atk*0.6+p.inf*0.2+p.phy*0.2),0)/P.length;},
sim(H,A){const sc={home:0,away:0},st={home:{sh:0},away:{sh:0}};const U={home:{mid:this.unit(H,'MID'),att:this.unit(H,'FOR'),def:this.unit(H,'DEF'),gk:H.find(p=>p.type==='GK')},away:{mid:this.unit(A,'MID'),att:this.unit(A,'FOR'),def:this.unit(A,'DEF'),gk:A.find(p=>p.type==='GK')}};
for(let i=0;i<92;i++){const hp=0.5+this.damp(U.home.mid,U.away.mid,0.018);const at=Math.random()<hp?'home':'away',df=at==='home'?'away':'home';
const adv=this.damp(U[at].att,U[df].def,0.015);if(Math.random()>0.26+adv)continue;st[at].sh++;
const T=at==='home'?H:A;const F=T.filter(p=>p.type==='FOR');const fin=F[Math.floor(Math.random()*F.length)];
let x=0.09+adv*0.4+(Math.random()-0.5)*0.08;x=Math.max(0.03,Math.min(0.38,x));
const g=Math.max(0.01,Math.min(0.65,x*(1+(fin.atk-75)*0.005)*(1-(U[df].gk.sto-75)*0.005)));
const ot=0.34+(fin.atk-70)*0.002;if(Math.random()>=ot)continue;if(Math.random()<g/ot)sc[at]++;}
return{sc,st};}};
function run(a,b,N=20000){const X=xi(a),Y=xi(b);let g=0,d=0,w=0,sh=0,sl={};for(let i=0;i<N;i++){const r=E.sim(X,Y);const h=r.sc.home,v=r.sc.away;g+=h+v;sh+=r.st.home.sh+r.st.away.sh;if(h===v)d++;if(h>v)w++;const k=Math.max(h,v)+'-'+Math.min(h,v);sl[k]=(sl[k]||0)+1;}
const top=Object.entries(sl).sort((x,y)=>y[1]-x[1]).slice(0,5).map(([k,v])=>k+' '+(100*v/N).toFixed(1)+'%').join(', ');
console.log(`${a} v ${b}: goals/g ${(g/N).toFixed(2)} | ${a} win ${(100*w/N).toFixed(1)}% draw ${(100*d/N).toFixed(1)}% | shots/g ${(sh/N).toFixed(1)} conv ${(100*g/sh).toFixed(1)}% | ${top}`);}
for(const [a,b] of [['france','brazil'],['france','newzealand'],['france','philippines'],['greece','mexico'],['germany','argentina']])run(a,b);
