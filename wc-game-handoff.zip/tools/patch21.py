import sys,re
s=open('world-cup-game-v20.html',encoding='utf-8').read()
def rep(old,new,count=1):
    global s
    n=s.count(old)
    if n!=count: sys.exit(f'EXPECTED {count} got {n}: {old[:80]!r}')
    s=s.replace(old,new)
NEW=['congo','mali','burkinafaso','guinea','angola']
# 1. pools
blocks={}; cur=None
for l in open('gb/groupB_pools.txt'):
    l=l.rstrip('\n')
    if l.startswith('NATION|'): cur=l.split('|')[1]; blocks[cur]=[]; continue
    if l: blocks[cur].append(l)
assert all('`' not in x and '$' not in x for b in blocks.values() for x in b)
ins=''.join(f"  {n}: `\n"+'\n'.join(blocks[n])+"\n`,\n" for n in NEW)
i=s.index('const PLAYER_POOL_COMPACT = {'); j=s.index('const FUTURE_PLAYER_POOL_COMPACT')
k=s.rindex('};',i,j)
s=s[:k]+ins+s[k:]
# 2. nations
rep("  {id:'philippines',name:'Philippines',     flag:'🇵🇭', strength:68},\n];",
    "  {id:'philippines',name:'Philippines',     flag:'🇵🇭', strength:68},\n"
    "  {id:'mali',       name:'Mali',            flag:'🇲🇱', strength:70},\n"
    "  {id:'burkinafaso',name:'Burkina Faso',    flag:'🇧🇫', strength:70},\n"
    "  {id:'guinea',     name:'Guinea',          flag:'🇬🇳', strength:68},\n"
    "  {id:'angola',     name:'Angola',          flag:'🇦🇴', strength:66},\n"
    "  {id:'congo',      name:'Congo',           flag:'🇨🇬', strength:64},\n];")
rep("china:'C', newzealand:'C', haiti:'C', philippines:'C',\n};",
    "china:'C', newzealand:'C', haiti:'C', philippines:'C',\n  mali:'C', burkinafaso:'C', guinea:'C', angola:'C', congo:'C',\n};")
rep("'haiti','philippines'],\n};","'haiti','philippines','mali','burkinafaso','guinea','angola','congo'],\n};")
rep("const NATION_PALETTES = {\n","const NATION_PALETTES = {\n"
    "  mali:        { primary:'#16a34a', secondary:'#facc15', tint:'#142417', label:'Les Aigles colors' },\n"
    "  burkinafaso: { primary:'#dc2626', secondary:'#16a34a', tint:'#241414', label:'Les Etalons colors' },\n"
    "  guinea:      { primary:'#dc2626', secondary:'#facc15', tint:'#241414', label:'Syli Nationale colors' },\n"
    "  angola:      { primary:'#dc2626', secondary:'#9ca3af', tint:'#1f1212', label:'Palancas Negras colors' },\n"
    "  congo:       { primary:'#dc2626', secondary:'#16a34a', tint:'#241414', label:'Diables Rouges colors' },\n")
rep("const NATION_MANAGERS = {\n","const NATION_MANAGERS = {\n  mali:        'Alain Giresse',\n  burkinafaso: 'Paul Put',\n  guinea:      'Michel Dussuyer',\n  angola:      'Luis Oliveira Goncalves',\n  congo:       'Adolphe Bibanzoulou',\n")
# 7. managers for the new nations
mg=[l.strip() for l in open('/mnt/user-data/outputs/managers-final.txt') if l.startswith('MGR|') and l.split('|')[1] in NEW]
a=s.index('const MANAGERS_COMPACT = `'); b=s.index('`;',a)
s=s[:b]+'\n'+'\n'.join(mg)+s[b:]
rep("if(result.length > 66) console.warn('getAllNations overflow: '+result.length+' nations');",
    "if(result.length > 71) console.warn('getAllNations overflow: '+result.length+' nations');")
rep('aria-label="Build version 20">v20</span>','aria-label="Build version 21">v21</span>')
open('world-cup-game-v21.html','w',encoding='utf-8').write(s)
print('ok managers added',len(mg))
