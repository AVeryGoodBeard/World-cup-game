import json,collections,re,sys
R=[]
for f in ['t22.json','fr22a.json','fr22b.json','sa22.json','zm22.json']: R+=json.load(open(f))
problems=collections.Counter(); examples=collections.defaultdict(list); checked=collections.Counter()
def winner(m):
    if m['goalsA']>m['goalsB']: return m['teamA']
    if m['goalsB']>m['goalsA']: return m['teamB']
    if 'win pens' in (m['extra'] or ''): return m['extra'].replace(' win pens','')
    return None
for i,r in enumerate(R):
    log=r['bracketLog'] or []; J=r['journey']; me=None
    by=collections.defaultdict(list)
    for m in log: by[m['stage']].append(m)
    # group standings from logged matches + player's own results
    teams=collections.defaultdict(lambda:[0,0]); adj=collections.defaultdict(set)
    for m in by['Group']:
        a,b=m['teamA'],m['teamB']; adj[a].add(b); adj[b].add(a)
        d=m['goalsA']-m['goalsB']; teams[a][1]+=d; teams[b][1]-=d
        if d>0: teams[a][0]+=3
        elif d<0: teams[b][0]+=3
        else: teams[a][0]+=1; teams[b][0]+=1
    gopps=[j[3] for j in J if j[0]=='Group Stage']
    for j in J:
        if j[0]=='Group Stage':
            mg,og=map(int,re.match(r'(\d+)–(\d+)',j[1]).groups())
            teams[j[3]][1]+=og-mg
            if og>mg: teams[j[3]][0]+=3
            elif og==mg: teams[j[3]][0]+=1
    # stage winners
    W={s:[winner(m) for m in by[s]] for s in ['R16','QF','SF','FINAL']}
    ko=[j for j in J if j[0]!='Group Stage']
    prevStage={'Round of 16':None,'Quarterfinal':'R16','Semifinal':'QF','Final':'SF'}
    sameStage={'Round of 16':'R16','Quarterfinal':'QF','Semifinal':'SF','Final':'FINAL'}
    for j in ko:
        opp=j[3]; rnd=j[0]; checked[rnd]+=1
        # opponent must not also be playing a logged match in the same round
        if any(opp in (m['teamA'],m['teamB']) for m in by[sameStage[rnd]]):
            problems['opp double-booked in '+rnd]+=1; examples['double'].append((i,rnd,opp))
        p=prevStage[rnd]
        if p and opp not in W[p]:
            problems['opp did not win the previous logged round ('+rnd+')']+=1; examples['prev'].append((i,rnd,opp,W[p]))
        if rnd=='Round of 16':
            # opp must be top two of its group
            grp={opp}|adj[opp]
            comp=set(); stack=[opp]
            while stack:
                t=stack.pop()
                if t in comp: continue
                comp.add(t); stack+=list(adj[t])
            ranked=sorted(comp,key=lambda t:(-teams[t][0],-teams[t][1]))
            if opp in gopps: pass  # in player's own group; skip exact rank check
            else:
                third=ranked[2] if len(ranked)>2 else None
                if ranked.index(opp)>1 and not (third and teams[third]==teams[opp]):
                    problems['R16 opp not top two of its group']+=1; examples['grp'].append((i,opp,[(t,teams[t]) for t in ranked]))
    # every logged knockout team must have survived the previous logged round (or be the player's conqueror)
    order={'Round of 16':0,'Quarterfinal':1,'Semifinal':2,'Final':3}; sorder={'R16':0,'QF':1,'SF':2,'FINAL':3}
    beat_at={j[3]:order[j[0]] for j in ko if j[2]=='win' or 'pen W' in j[1]}
    lost_to=[j[3] for j in ko if j[2]=='loss' or 'pen L' in j[1]]
    for s,p in [('QF','R16'),('SF','QF'),('FINAL','SF')]:
        for m in by[s]:
            for t in (m['teamA'],m['teamB']):
                checked['logged '+s]+=1
                if t not in W[p] and t not in lost_to:
                    problems['logged '+s+' team never won '+p]+=1; examples['chain'].append((i,s,t))
                if t in beat_at and sorder[s]>beat_at[t]:
                    problems['team the player eliminated reappears in '+s]+=1; examples['ghost'].append((i,s,t))
print('runs',len(R)); print('checked',dict(checked)); print('problems',dict(problems))
for k,v in examples.items(): print(k, v[:4])
