import collections, statistics as st, json, unicodedata, re
STARS = {
 'congo': {"Francois M'Pele":14,"Paul Moukila":14,"Jean-Michel M'Bono":10,"Jonas Bahamboula":8,"Maxime Matsima":8,"Noel Minga":6,"Thievy Bifouma":6,"Prince Oniangue":6,"Delvin N'Dinga":5,"Rolf-Christel Guie-Mien":6},
 'mali': {"Salif Keita":22,"Frederic Kanoute":16,"Seydou Keita":14,"Mahamadou Diarra":14,"Yves Bissouma":10,"Mohamed Sissoko":8,"Amadou Haidara":8,"Moussa Marega":6,"Hamari Traore":5,"Cheick Diabate":5,"Bassala Toure":4,"Djigui Diarra":4,"Adama Tamboura":3,"Soumaila Coulibaly":3},
 'burkinafaso': {"Jonathan Pitroipa":12,"Edmond Tapsoba":12,"Moumouni Dagano":10,"Bertrand Traore":10,"Charles Kabore":8,"Aristide Bance":8,"Alain Traore":8,"Herve Koffi":8,"Bakary Kone":6,"Dango Ouattara":6,"Issa Kabore":5,"Prejuce Nakoulma":5},
 'guinea': {"Cherif Souleymane":16,"Petit Sory":12,"Naby Keita":12,"Serhou Guirassy":12,"Pascal Feindouno":10,"Titi Camara":10,"Bobo Balde":8,"Kamil Zayatte":6,"Pablo Thiam":6,"Souleymane Oulare":6,"Amadou Diawara":6,"Mouctar Diakhaby":5,"Kemoko Camara":4,"Naby Yattara":4},
 'angola': {"Akwa":12,"Flavio Amado":10,"Manucho":8,"Mantorras":6,"Gelson Dala":6,"Ze Kalanga":6,"Andre Macanga":6,"Joao Ricardo":6,"Bastos":6,"Kali":5,"Zito Luvumbo":5,"Mabululu":5,"Jamba":4,"Paulao":4,"Quinzinho":4},
}
STARS={k:{x.replace("'",''):v for x,v in d.items()} for k,d in STARS.items()}
TYPE={'GK':'GK','DF':'DEF','MF':'MID','FW':'FOR'}
existing={}; nat=None
for l in open('/mnt/user-data/outputs/current-player-pools-v18.txt'):
    l=l.strip()
    if l.startswith('NATION|'): nat=l.split('|')[1]; continue
    if l and not l.startswith('#'):
        p=l.split('|'); existing[(p[1] if p[0]=='GK' else p[2]).lower()]=nat
def era(y1,y2):
    d1,d2=y1//10*10,y2//10*10
    if d1==d2: return f'{d1}s'
    return f'{d1}s-{str(d2)[2:]}s'
def clamp(v,lo=25,hi=93): return max(lo,min(hi,int(round(v))))
report={}; out_blocks=[]
for n in ['congo','mali','burkinafaso','guinea','angola']:
    rows=[l.strip().split('|') for l in open(f'{n}.txt') if l.strip()]
    # group by name and GK/outfield
    g=collections.defaultdict(list)
    for y,pos,name in rows:
        name=unicodedata.normalize('NFKD',name).encode('ascii','ignore').decode().replace("'","")
        g[(name, pos=='GK')].append((int(y),pos))
    players=[]
    for (name,isgk),apps in g.items():
        apps.sort()
        # split homonyms: gap of more than 8 years between consecutive appearances
        chunks=[[apps[0]]]
        for a,b in zip(apps,apps[1:]):
            if b[0]-a[0]>8: chunks.append([b])
            else: chunks[-1].append(b)
        for ch in chunks:
            pos=collections.Counter(p for _,p in ch).most_common(1)[0][0]
            yrs=[y for y,_ in ch]
            players.append(dict(name=name,type=TYPE[pos],first=min(yrs),last=max(yrs),apps=len(ch)))
    # one display name per nation: keep the higher-stature homonym
    best={}
    for p in players:
        p['raw']=64+3*min(p['apps'],6)+STARS[n].get(p['name'],0)
        k=p['name']
        if k not in best or (p['raw'],p['last'])>(best[k]['raw'],best[k]['last']): best[k]=p
    players=list(best.values())
    quota={'GK':6,'DEF':20,'MID':20,'FOR':21}
    chosen=[]
    for t,q in quota.items():
        cand=sorted([p for p in players if p['type']==t],key=lambda p:(-p['raw'],-p['apps'],-p['last']))
        chosen+=cand[:q]
    short=67-len(chosen)
    if short>0:
        rest=sorted([p for p in players if p not in chosen and p['type']!='GK'],key=lambda p:-p['raw']); chosen+=rest[:short]
    # sub-positions (provisional: the squad pages list only GK/DF/MF/FW)
    OVR={'FB':{'Hamari Traore','Adama Tamboura','Falaye Sacko','Massadio Haidara','Charles Traore','Issa Kabore','Steeve Yago','Saidou Panandetiguiri','Issiaga Sylla','Marco Airosa','Nurio Fortuna','Clinton Mata','Bruno Gaspar','Arnold Bouka Moutou'},
         'W':{'Jonathan Pitroipa','Moussa Djenepo','Ze Kalanga','Bertrand Traore','Dango Ouattara','Cyrille Bayala','Prejuce Nakoulma','Fode Mansare','Ibrahima Traore','Francois Kamano','Zito Luvumbo','Felicio Milson'},
         'DM':{'Mahamadou Diarra','Mohamed Sissoko','Yves Bissouma','Charles Kabore','Andre Macanga','Amadou Diawara','Pablo Thiam','Delvin NDinga','Diadie Samassekou','Florent Rouamba'},
         'AMC':{'Pascal Feindouno','Alain Traore','Stephane Aziz Ki','Kamory Doumbia','Cherif Souleymane'}}
    for p in chosen:
        if p['type']=='GK': continue
        p['pos']={'DEF':'CB','MID':'CM','FOR':'STR'}[p['type']]
        for k,names in OVR.items():
            if p['name'] in names:
                if k=='FB' and p['type']=='DEF': p['pos']='FB'
                elif k=='W' and p['type'] in ('MID','FOR'): p['pos']='W'
                elif k in ('DM','AMC') and p['type']=='MID': p['pos']=k
    def attrs(p,off):
        r=p['raw']+off
        if p['type']=='GK': return [clamp(r),clamp(r-3),clamp(r-7)]
        if p['type']=='FOR': return [clamp(r+3),clamp(28+(r-60)/3),clamp(r-3),clamp(r-2)]
        if p['type']=='MID':
            if p['pos']=='W': return [clamp(r+1),clamp(r-20),clamp(r-4),clamp(r-2)]
            if p['pos']=='DM': return [clamp(r-10),clamp(r+1),clamp(r),clamp(r-2)]
            if p['pos']=='AMC': return [clamp(r+2),clamp(r-16),clamp(r-6),clamp(r)]
            return [clamp(r-2),clamp(r-6),clamp(r-3),clamp(r)]
        if p['pos']=='FB': return [clamp(r-12),clamp(r),clamp(r-2),clamp(r-5)]
        return [clamp(32+(r-60)/4),clamp(r+2),clamp(r),clamp(r-4)]
    # calibrate a nation offset: median player 72-74, top-10 average at most 84
    def bench(off):
        mx=[max(attrs(p,off)) for p in chosen if p['type']!='GK']
        return st.median(mx), st.mean(sorted(mx,reverse=True)[:10]), max(mx)
    off=0
    for o in range(-10,6):
        med,top,b=bench(o)
        if 72<=med<=74 and top<=84.5: off=o; break
    else:
        off=min(range(-10,6),key=lambda o:abs(bench(o)[0]-73))
    med,top,b=bench(off)
    lines=[]
    for p in sorted(chosen,key=lambda p:(['GK','DEF','MID','FOR'].index(p['type']),-p['raw'])):
        e=era(p['first'],p['last']); a=attrs(p,off)
        lines.append(f"GK|{p['name']}|{e}|{a[0]}|{a[1]}|{a[2]}" if p['type']=='GK' else f"{p['type']}|{p['pos']}|{p['name']}|{e}|{a[0]}|{a[1]}|{a[2]}|{a[3]}")
    clashes=[p['name'] for p in chosen if p['name'].lower() in existing]
    c=collections.Counter(p['type'] for p in chosen)
    report[n]=dict(unique=len(players),pool=len(chosen),mix=dict(c),offset=off,median=med,top10=round(top,1),best=b,clashes=clashes)
    out_blocks.append((n,lines))
json.dump(report,open('report.json','w'),indent=1)
with open('groupB_pools.txt','w') as f:
    for n,lines in out_blocks:
        f.write(f'NATION|{n}|{len(lines)} players\n'+'\n'.join(lines)+'\n\n')
for k,v in report.items(): print(k,v)
