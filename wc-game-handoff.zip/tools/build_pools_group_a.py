import collections, statistics as st, json, unicodedata, re
STARS = {
 'drcongo': {"Ndaye Mulamba":14,"Mwamba Kazadi":8,"Kakoko Etepe":8,"Kidumu Mantantu":8,"Mayanga Maku":6,"Kibonge Mafu":6,"Bwanga Tshimen":6,"Chancel Mbemba":8,"Dieumerci Mbokani":8,"Yannick Bolasie":6,"Cedric Bakambu":6,"Yoane Wissa":6,"Youssouf Mulumbu":5,"Robert Kidiaba":5,"Mwepu Ilunga":4,"Lobilo Boba":4},
 'zambia': {"Kalusha Bwalya":16,"Godfrey Chitalu":16,"Christopher Katongo":10,"Rainford Kalaba":8,"Kennedy Mweene":8,"Stoppila Sunzu":8,"Patson Daka":8,"Kenneth Malitoli":6,"Bernard Chanda":6,"Emmanuel Mayuka":5,"Dickson Makwaza":5,"Joel Bwalya":4,"Elijah Litana":4},
 'southafrica': {"Lucas Radebe":12,"Benni McCarthy":12,"Doctor Khumalo":10,"Mark Fish":8,"Steven Pienaar":8,"Shaun Bartlett":8,"Philemon Masinga":6,"Quinton Fortune":6,"Aaron Mokoena":6,"Itumeleng Khune":6,"Ronwen Williams":6,"Siphiwe Tshabalala":6,"Neil Tovey":6,"John Moshoeu":5,"Percy Tau":5,"Teboho Mokoena":4,"Andre Arendse":4},
 'sudan': {"Nasreldin Jaksa":12,"Ali Gagarin":10,"Hasabu El-Sagheer":10,"Haitham Mustafa":8,"Faisal Agab":8,"Amin Zaki":6,"Mohamed Abdelrahman":5,"Mudather Karika":5,"Akram El Hadi Salim":4,"Muhamed Abdelfatah Zughbir":4},
 'ethiopia': {"Mengistu Worku":14,"Luciano Vassallo":12,"Italo Vassallo":8,"Getachew Wolde":6,"Saladin Said":8,"Getaneh Kebede":6,"Adane Girma":5,"Shimelis Bekele":5,"Gila-Michael Tekle-Mariam":4},
}
STARS={k:{x.replace("'",''):v for x,v in d.items()} for k,d in STARS.items()}
TYPE={'GK':'GK','DF':'DEF','MF':'MID','FW':'FOR'}
existing={}; nat=None
for l in open('/mnt/user-data/outputs/current-player-pools-v18.txt'):
    l=l.strip()
    if l.startswith('NATION|'): nat=l.split('|')[1]; continue
    if l and not l.startswith('#'):
        p=l.split('|'); existing[(p[1] if p[0]=='GK' else p[2]).lower()]=nat
for l in open('../gb/groupB_pools.txt'):
    p=l.strip().split('|')
    if len(p)>3: existing[(p[1] if p[0]=='GK' else p[2]).lower()]='groupB'
def era(y1,y2):
    d1,d2=y1//10*10,y2//10*10
    if d1==d2: return f'{d1}s'
    return f'{d1}s-{str(d2)[2:]}s'
def clamp(v,lo=25,hi=93): return max(lo,min(hi,int(round(v))))
report={}; out_blocks=[]
for n in ['drcongo','zambia','southafrica','sudan','ethiopia']:
    rows=[l.strip().split('|') for l in open(f'{n}.txt') if l.strip()]
    # group by name and GK/outfield
    g=collections.defaultdict(list)
    for y,pos,name in rows:
        name=unicodedata.normalize('NFKD',name).encode('ascii','ignore').decode().replace("'","")
        g[(name, pos=='GK')].append((int(y),pos))
    players=[]
    for (name,isgk),apps in g.items():
        apps.sort()
        # split homonyms: gap of more than 8 years between consecutive appearances
        chunks=[[apps[0]]]
        for a,b in zip(apps,apps[1:]):
            if b[0]-a[0]>8: chunks.append([b])
            else: chunks[-1].append(b)
        for ch in chunks:
            pos=collections.Counter(p for _,p in ch).most_common(1)[0][0]
            yrs=[y for y,_ in ch]
            players.append(dict(name=name,type=TYPE[pos],first=min(yrs),last=max(yrs),apps=len(ch)))
    # one display name per nation: keep the higher-stature homonym
    best={}
    for p in players:
        p['raw']=64+3*min(p['apps'],6)+STARS[n].get(p['name'],0)
        k=p['name']
        if k not in best or (p['raw'],p['last'])>(best[k]['raw'],best[k]['last']): best[k]=p
    players=list(best.values())
    quota={'GK':6,'DEF':20,'MID':20,'FOR':21}
    chosen=[]
    if len(players)<=67: quota={'GK':99,'DEF':99,'MID':99,'FOR':99}
    for t,q in quota.items():
        cand=sorted([p for p in players if p['type']==t],key=lambda p:(-p['raw'],-p['apps'],-p['last']))
        chosen+=cand[:q]
    short=min(67,len(players))-len(chosen)
    if short>0:
        rest=sorted([p for p in players if p not in chosen and p['type']!='GK'],key=lambda p:-p['raw']); chosen+=rest[:short]
    # sub-positions (provisional: the squad pages list only GK/DF/MF/FW)
    OVR={'FB':{'Mwepu Ilunga','Arthur Masuaku','Gedeon Kalulu','Joris Kayembe','Issama Mpeko','Tsepo Masilela','Siboniso Gaxa','Khuliso Mudau','Aubrey Modiba','Bradley Carnell','Davies Nkausu','Joseph Musonda'},
         'W':{'Yannick Bolasie','Meschak Elia','Silas Katompa Mvumpa','Theo Bongonda','Siphiwe Tshabalala','Helman Mkhalele','Lameck Banda','Rainford Kalaba','Percy Tau','Neeskens Kebano'},
         'DM':{'Youssouf Mulumbu','Charles Pickel','MacBeth Sibaya','Kagisho Dikgacoi','Teboho Mokoena'},
         'AMC':{'Gael Kakuta','Clatous Chama','Themba Zwane','Doctor Khumalo','Steven Pienaar','Teko Modise'}}
    for p in chosen:
        if p['type']=='GK': continue
        p['pos']={'DEF':'CB','MID':'CM','FOR':'STR'}[p['type']]
        for k,names in OVR.items():
            if p['name'] in names:
                if k=='FB' and p['type']=='DEF': p['pos']='FB'
                elif k=='W' and p['type'] in ('MID','FOR'): p['pos']='W'
                elif k in ('DM','AMC') and p['type']=='MID': p['pos']=k
    def attrs(p,off):
        r=p['raw']+off
        if p['type']=='GK': return [clamp(r),clamp(r-3),clamp(r-7)]
        if p['type']=='FOR': return [clamp(r+3),clamp(28+(r-60)/3),clamp(r-3),clamp(r-2)]
        if p['type']=='MID':
            if p['pos']=='W': return [clamp(r+1),clamp(r-20),clamp(r-4),clamp(r-2)]
            if p['pos']=='DM': return [clamp(r-10),clamp(r+1),clamp(r),clamp(r-2)]
            if p['pos']=='AMC': return [clamp(r+2),clamp(r-16),clamp(r-6),clamp(r)]
            return [clamp(r-2),clamp(r-6),clamp(r-3),clamp(r)]
        if p['pos']=='FB': return [clamp(r-12),clamp(r),clamp(r-2),clamp(r-5)]
        return [clamp(32+(r-60)/4),clamp(r+2),clamp(r),clamp(r-4)]
    # calibrate a nation offset: median player 72-74, top-10 average at most 84
    def bench(off):
        mx=[max(attrs(p,off)) for p in chosen if p['type']!='GK']
        return st.median(mx), st.mean(sorted(mx,reverse=True)[:10]), max(mx)
    off=0
    for o in range(-10,6):
        med,top,b=bench(o)
        if 72<=med<=74 and top<=84.5: off=o; break
    else:
        off=min(range(-10,6),key=lambda o:abs(bench(o)[0]-73))
    med,top,b=bench(off)
    lines=[]
    for p in sorted(chosen,key=lambda p:(['GK','DEF','MID','FOR'].index(p['type']),-p['raw'])):
        e=era(p['first'],p['last']); a=attrs(p,off)
        lines.append(f"GK|{p['name']}|{e}|{a[0]}|{a[1]}|{a[2]}" if p['type']=='GK' else f"{p['type']}|{p['pos']}|{p['name']}|{e}|{a[0]}|{a[1]}|{a[2]}|{a[3]}")
    clashes=[p['name'] for p in chosen if p['name'].lower() in existing]
    c=collections.Counter(p['type'] for p in chosen)
    report[n]=dict(unique=len(players),pool=len(chosen),mix=dict(c),offset=off,median=med,top10=round(top,1),best=b,clashes=clashes)
    out_blocks.append((n,lines))
json.dump(report,open('report.json','w'),indent=1)
with open('groupA_pools.txt','w') as f:
    for n,lines in out_blocks:
        f.write(f'NATION|{n}|{len(lines)} players\n'+'\n'.join(lines)+'\n\n')
for k,v in report.items(): print(k,v)
